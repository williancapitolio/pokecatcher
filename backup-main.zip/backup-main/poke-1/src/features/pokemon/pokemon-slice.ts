import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";

import { getPokemonsList } from "../../services/Api";

interface pokemonState {
  pokemons: [] /* Pokemon[] */ | null;
  singlePokemon: string /* Pokemon */ | null;
  loading: boolean;
  errors: any;
}

const initialState: pokemonState = {
  pokemons: [],
  singlePokemon: null,
  loading: false,
  errors: null,
};

export const getPokemons = createAsyncThunk(
  /* <> */ "pokemons/getPokemons",
  async (_, thunkAPI) => {
    try {
      await getPokemonsList();
    } catch (error) {
      return thunkAPI.rejectWithValue(error);
    }
  }
);

export const pokemonSlice = createSlice({
  name: "pokemons",
  initialState,
  reducers: {
    favorite: () => {},
  },
  extraReducers: (builder) => {
    builder.addCase(getPokemons.pending, (state) => {
      state.loading = true;
    });
    builder.addCase(getPokemons.fulfilled, (state, action) => {
      state.pokemons = action.payload;
      state.loading = false;
    });
    builder.addCase(getPokemons.rejected, (state, action) => {
      state.loading = false;
      state.errors = action.payload;
    });
  },
});

export const { favorite } = pokemonSlice.actions;
