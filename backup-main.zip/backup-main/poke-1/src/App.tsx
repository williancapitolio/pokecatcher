import { useEffect } from "react";
import { getPokemonsList } from "./services/Api";

export function App() {
  useEffect(() => {
    getPokemonsList();
  }, []);

  return (
    <>
      <h2>Teste</h2>
    </>
  );
}
