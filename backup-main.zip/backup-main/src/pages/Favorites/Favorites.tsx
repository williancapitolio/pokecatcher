export const Favorites = () => {
    return (
      <>
        <div></div>
      </>
    );
  };
  