import { useInfiniteScroll } from "../../hooks/useInfiniteScroll";

import { Header } from "../../components/Header";
import { Loader } from "../../components/Loader";
import { CharacterCard } from "../../components/CharacterCard";

import styles from "./Home.module.scss";

export const Home = () => {
  const { loading, data, scrollLoadind, endDataPage } = useInfiniteScroll();

  return (
    <>
      <Header />
      <h3
        style={{
          width: "100%",
          maxWidth: "64rem",
          padding: "1.5rem 1rem 1rem 1rem",
        }}
      >
        Personagens
      </h3>
      {loading && <Loader />}
      <section className={styles.home}>
        {data.map((character) => (
          <CharacterCard characterData={character} key={character.id} />
        ))}
      </section>
      {scrollLoadind && <Loader />}
      {endDataPage && <h2>Fim dos resultados</h2>}
    </>
  );
};
