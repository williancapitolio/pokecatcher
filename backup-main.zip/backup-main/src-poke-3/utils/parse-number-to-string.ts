export function ParseNumberToString(data: number) {
  return `${data}`;
}
