export { CardPokemon } from "./CardPokemon";
