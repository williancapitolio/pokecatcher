export { Pokemon } from "./Pokemon";
