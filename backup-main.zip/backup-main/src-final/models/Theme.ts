export interface Theme {
  title: "dark" | "light";
}
