export interface User {
  name: string;
  modalFormUser: boolean;
}
