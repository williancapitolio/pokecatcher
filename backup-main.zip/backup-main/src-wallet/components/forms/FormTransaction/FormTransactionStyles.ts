import styled from "styled-components";

export const Wrapper = styled.section`
  padding-inline: 1rem;
  position: relative;
`;

export const Form = styled.form`
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: space-between;
  background-color: ${(props) => props.theme.colors.background.secondary};
  box-shadow: ${(props) => props.theme.colors.boxShadow};
  border-radius: 0.5rem;
  padding: 1rem;
`;

export const Field = styled.div`
  display: flex;
  flex-direction: column;
  width: 25%;
  gap: 0.5rem;
`;

export const Label = styled.label`
  font-size: 0.75rem;
  cursor: pointer;
`;

export const Input = styled.input`
  background-color: ${(props) => props.theme.colors.background.secondary};
  padding: 0.5rem;
  border: 0.125rem solid ${(props) => props.theme.colors.text.primary};
  border-radius: 0.25rem;

  &:focus {
    outline: none;
    border: 0.125rem solid ${(props) => props.theme.colors.button.ok};
  }
`;

export const Select = styled.select`
  background-color: ${(props) => props.theme.colors.background.secondary};
  padding: 0.5rem;
  border: 0.125rem solid ${(props) => props.theme.colors.text.primary};
  border-radius: 0.25rem;

  &:focus {
    outline: none;
    border: 0.125rem solid ${(props) => props.theme.colors.button.ok};
  }
`;

export const Option = styled.option`
  background-color: ${(props) => props.theme.colors.background.secondary};
  padding: 0.5rem;
`;

export const Submit = styled.button`
  height: 3.5rem;
  width: 6rem;
  background-color: ${(props) => props.theme.colors.button.ok};
  border-radius: 0.5rem;
  text-transform: uppercase;
  font-size: 0.75rem;
  font-weight: 700;
  border: 0.125rem solid transparent;

  &:focus {
    outline: none;
  }

  &:hover {
    border: 0.125rem solid ${(props) => props.theme.colors.button.ok};
    color: ${(props) => props.theme.colors.button.ok};
    background-color: ${(props) => props.theme.colors.text.primary};
  }
`;

export const ErrorMsg = styled.span``;
