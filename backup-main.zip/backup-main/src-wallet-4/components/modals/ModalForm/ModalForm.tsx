import { useState } from "react";

import { useDispatch } from "react-redux";

import { useAppSelector } from "../../../hooks/use-app-selector";

import { setUser, toggleModal } from "../../../features/user/user-slice";

import { DefaultInput } from "../../inputs/DefaultInput";
import { Default } from "../../buttons/Default";

import { BsXLg } from "react-icons/bs";

import * as S from "./ModalFormStyles";

export const ModalForm = () => {
  const modal = useAppSelector((state) => state.user.modalFormUser);
  const name = useAppSelector((state) => state.user.name);

  const dispatch = useDispatch();

  const [username, setUsername] = useState<string>(name);

  const checkIfClickOutOfModal = (ev: React.BaseSyntheticEvent) => {
    ev.target.id === "wrapperOutOfModal" && handleCloseModal();
  };

  const handleCloseModal = () => {
    dispatch(toggleModal());
  };

  const handleConfirmUsername = (ev: React.SyntheticEvent) => {
    ev.preventDefault();
    if (username) dispatch(setUser(username));
  };

  if (modal) {
    return (
      <S.Wrapper id="wrapperOutOfModal" onClick={checkIfClickOutOfModal}>
        <S.Container>
          <S.Header>
            <S.IconClose onClick={handleCloseModal}>
              <BsXLg />
            </S.IconClose>
          </S.Header>
          <S.Form onSubmit={() => console.log(1)}>
            <S.Label htmlFor="name">Nome</S.Label>
            <DefaultInput
              type="text"
              name="name"
              id="name"
              changeFunction={(ev: React.SyntheticEvent) =>
                setUsername((ev.target as HTMLInputElement).value)
              }
              value={username}
            />
            <S.Btns>
              <Default
                type="cancel"
                btnAction={handleCloseModal}
                text="Cancelar"
              />
              <Default
                type="confirm"
                btnAction={handleConfirmUsername}
                text="Confirmar"
              />
            </S.Btns>
          </S.Form>
        </S.Container>
      </S.Wrapper>
    );
  } else return null;
};
