import { Layout } from "./components/structures/Layout";

export const App = () => {
  return <Layout />;
};
